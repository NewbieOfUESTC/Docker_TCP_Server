#!/bin/sh
kill -9 $(pidof easydarwin)
