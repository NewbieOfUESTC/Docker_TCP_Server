#!/bin/sh
./easydarwin -c easydarwin.xml -d
