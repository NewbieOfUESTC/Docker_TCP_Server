#!/bin/sh
kill -9 $(pidof easycms)
