#!/bin/sh
./easycms -c easycms.xml -d
